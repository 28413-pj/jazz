package com.example.averagecurrencyexchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AverageCurrencyExchangeApplicationTests {

    @Test
    void contextLoads() {
    }

}
