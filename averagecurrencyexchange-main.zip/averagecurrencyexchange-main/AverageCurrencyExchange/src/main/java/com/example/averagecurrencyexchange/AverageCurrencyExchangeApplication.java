package com.example.averagecurrencyexchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AverageCurrencyExchangeApplication {

    public static void main(String[] args) {
        SpringApplication.run(AverageCurrencyExchangeApplication.class, args);
    }

}
